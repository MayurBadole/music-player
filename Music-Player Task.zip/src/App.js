import MusicPlayers from "./musicPlayer/MusicPlayer";

const App = () => {
  return <MusicPlayers />;
};

export default App;
